
CKEDITOR.plugins.setLang( 'equation', 'en',
{
	equation :
	{
		title		: 'CodeCogs Equation Editor',
		menu    : 'Equation',
		toolbar		: 'Create Equation',
		edit		: 'Edit Equation',
	}
});
